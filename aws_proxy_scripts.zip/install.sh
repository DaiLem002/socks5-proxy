#!/bin/bash
exec > /var/log/cloud-init-output.log 2>&1

echo "--- Bắt đầu cấu hình Proxy AWS SOCKS5 ---"
apt update -y
apt install curl -y

echo "Tải script aws.sh từ GitHub..."
curl -o /tmp/aws.sh https://raw.githubusercontent.com/DaiLem002/socks5-proxy/main/aws.sh
chmod +x /tmp/aws.sh

echo "Đang thiết lập biến cấu hình..."
PROXY_PORT="8888"
PROXY_USERNAME="dailem"
PROXY_PASSWORD="dailem2002"
ALLOW_IP="0.0.0.0/0"
ENABLE_TELEGRAM="1"
BOT_TOKEN="7318042852:AAHxm5Jcu42Vju60RJEhDifsuGMYwh8jlxA"
USER_ID="7731707524"

source /tmp/aws.sh

echo "Khởi tạo proxy..."
setup_proxy_single_port \
  "$PROXY_PORT" \
  "$PROXY_PASSWORD" \
  "$ALLOW_IP" \
  "$ENABLE_TELEGRAM" \
  "$BOT_TOKEN" \
  "$USER_ID"

echo "--- Hoàn tất cấu hình ---"
